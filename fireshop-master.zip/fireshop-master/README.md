Create a fresh app using:
ionic start app_name 

And install Firebase using:
npm i firebase --save

Then replace src folder with my code

Don't forget to initialize your firebase in app.component.ts✌️
